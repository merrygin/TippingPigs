<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="tropical shores, just trees" tilewidth="80" tileheight="112" tilecount="12" columns="6">
 <image source="tropical shores, just trees.png" width="480" height="224"/>
</tileset>
