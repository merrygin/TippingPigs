<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.02.15" name="tropical shores" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="tropical shores.png" width="256" height="256"/>
 <tile id="7">
  <animation>
   <frame tileid="7" duration="300"/>
   <frame tileid="39" duration="300"/>
   <frame tileid="71" duration="300"/>
   <frame tileid="103" duration="300"/>
  </animation>
 </tile>
 <tile id="8">
  <animation>
   <frame tileid="8" duration="300"/>
   <frame tileid="40" duration="300"/>
   <frame tileid="72" duration="300"/>
   <frame tileid="104" duration="300"/>
  </animation>
 </tile>
 <tile id="23">
  <animation>
   <frame tileid="23" duration="300"/>
   <frame tileid="55" duration="300"/>
   <frame tileid="87" duration="300"/>
   <frame tileid="119" duration="300"/>
  </animation>
 </tile>
 <tile id="24">
  <animation>
   <frame tileid="24" duration="300"/>
   <frame tileid="56" duration="300"/>
   <frame tileid="88" duration="300"/>
   <frame tileid="120" duration="300"/>
  </animation>
 </tile>
</tileset>
